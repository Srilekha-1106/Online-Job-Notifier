import React from "react";

//This page gets loaded as soon as the user clicks on submit button
function Submit(){

    return(
        <div className = "submitPage">
            <h1>Thankyou!</h1>
            <p>Your Information is recorded and you'll be receiving updates as per the scheduling time you entered.</p>
        </div>    
    );
}

export default Submit;