import React from "react";

//The header component of the page
function Header(){
    return(
        <header>
            <h1>Online Job Notifier</h1>
        </header>
    );
}

export default Header;